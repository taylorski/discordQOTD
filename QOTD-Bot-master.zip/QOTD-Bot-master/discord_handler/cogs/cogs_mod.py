from discord.ext.commands import command,Context, Bot,bot_has_permissions
from discord import Member, TextChannel,Reaction,Role
from django.utils import timezone
from BBase.discord.cog_interface import ICog,AuthorState
from db.models import Question,Answer
from django.db.models import Q
import asyncio
from discord_handler.meta import convert_str_date,pretty_time
from datetime import timedelta,datetime
from texttable import Texttable
from discord_handler.meta import send_table
from typing import List

class Mod(ICog):
    def __init__(self,bot : Bot):
        super().__init__(bot,AuthorState.Mod)

    @command(
        name='trigger_answering',
        brief='Triggers answering.',
        help='Triggers answering. Will set the next answering round to now. The next one will be on the'
             ' following day.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True,
        add_reactions=True,

    )
    async def trigger_answering(self,ctx : Context):
        self.g.next_answer_round = timezone.now()
        self.g.save()
        qcmd = self.bot.get_cog('QuestionCmd')
        await qcmd.action_crawler(ctx.guild)
        await ctx.send("Started answering round.")

    @command(
        name='force_answer_end',
        brief='Ends the answering phase right now.'
    )
    async def force_answer_end(self,ctx : Context):
        bot_questions = self.bot.get_cog('QuestionCmd')
        a_channel: TextChannel = ctx.guild.get_channel(self.g.answer_channel)
        await ctx.send("Force ending answering")
        await bot_questions.process_end_answer(self.g,ctx.guild,a_channel)
        await ctx.send("Finished")

    @command(
        name='time',
        brief='Sets the time and duration for answering.',
        help='Sets the time and duration for answering. Time needs to be in the format HH:MM and the duration'
             'needs to use time shortcuts, for example 1d2h1m.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def time(self,ctx : Context, time : str, duration : str):
        try:
            time = datetime.strptime(time,'%H:%M').time()
            dur = convert_str_date(duration)
        except:
            await ctx.send("Sorry, i can't understand your input. Be sure to provide the time in the format"
                           " HH:MM, and the duration with shortcuts, for example 1d2h1m.")
            return

        self.g.answer_start_time = time
        self.g.answer_duration = dur
        self.g.save()
        await ctx.send(f"Set answering to {time} for {pretty_time(dur)}")

    @command(
        name='next',
        brief='Shows the next questions that are up.',
        help='Shows the next questions that are up.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def up_next(self,ctx : Context):
        q = Question.objects.filter(u__g=self.g,up_next=True)
        table = Texttable()
        tabledata = [["id","Question", "User", "Added", "Shown"]]
        for q_obj in q:
            q_obj : Question
            tabledata.append([f'{q_obj.id}',f'{q_obj.question}',f'{q_obj.u.d_name}'
                                 ,f"{q_obj.time.strftime('%Y-%m-%d %H:%M')}",f'{q_obj.show_count}'])

        table.set_deco(Texttable.VLINES | Texttable.HEADER | Texttable.BORDER)
        table.add_rows(tabledata, True)
        table.set_cols_width([4,30, 10, 17, 5])
        txt = "```" + table.draw() + "```"
        await send_table(ctx.send,txt)

    @command(
        name='rm',
        brief='Deletes a question from the database.',
        help='Deletes a question from the database. Use the next command to find the correct id for '
             'the question you want to delete.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True,
    )
    async def rm (self,ctx : Context, id : int):
        try:
            q = Question.objects.get(u__g=self.g,id=id)
        except Question.DoesNotExist:
            await ctx.send(f"Question with id {id} does not exist. Recheck using __{self.g.prefix}next__")
            return

        msg = await ctx.send(f"Do you really want to delete \n __{q.question}__")

        def check_user_message(reaction: Reaction, user: Member):
            return reaction.message.id == msg.id and user == ctx.author and (reaction.emoji =='✅' or reaction.emoji =='❌')

        await msg.add_reaction('✅')
        await msg.add_reaction('❌')
        try:
            reaction,_ = await ctx.bot.wait_for('reaction_add',check=check_user_message,timeout=200)
        except asyncio.TimeoutError:
            await ctx.send("Sorry, you timed out.")
            raise asyncio.TimeoutError

        if reaction.emoji == '✅':
            await ctx.send(f"Deleted \n__{q.question}__")
            q.delete()
        else:
            await ctx.send(f"Cancelled")

    @command(
        name='settings',
        brief='Shows current settings for QOTDBot.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def settings(self,ctx : Context):
        question_channel : TextChannel= ctx.guild.get_channel(self.g.question_channel)
        answer_channel : TextChannel= ctx.guild.get_channel(self.g.answer_channel)
        hof_channel : TextChannel= ctx.guild.get_channel(self.g.hall_of_fame_channel)
        qotd_role : Role = ctx.guild.get_role(self.g.qotd_role)
        try:
            mod_role : List[str] = [ctx.guild.get_role(i).mention for i in self.g.m_role()]
        except TypeError:
            mod_role = []


        text = f"**QOTD Bot settings for {ctx.guild.name}:**\n\n"
        text += f"__Question channel__: {question_channel.mention if question_channel is not None else question_channel}\n"
        text += f"__Answer channel__: {answer_channel.mention if answer_channel is not None else answer_channel}\n"
        text += f"__Hall of fame channel__: {hof_channel.mention if hof_channel is not None else hof_channel}\n"
        text += f"__Answer time__: {self.g.answer_start_time} for {pretty_time(self.g.answer_duration)}\n"
        text += f"__Next planned answering time__: " \
            f"{self.g.next_answer_round.strftime('%Y-%m-%d %H:%M') if self.g.next_answer_round is not None else self.g.next_answer_round}\n"
        text += f"__QOTD role__: {qotd_role.mention if qotd_role is not None else qotd_role}\n"
        text += f"__Question maximum show count__: {self.g.show_up_count}\n"
        text += f"__Here/role ping enabled__: {self.g.enable_ping}\n"
        text += f"__Question limit__: {self.g.question_limit}\n"
        text += f"__Anonym answering enabled__: {self.g.anonymize_answering}"
        await ctx.send(text)

    @command(
        name='reset_count',
        brief='Resets the show count for old questions.',
        help='Resets the show count for old questions. Already asked questions will not be repeated.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def reset_count(self,ctx : Context):
        number = Question.objects.filter(u__g=self.g).update(show_count=0)
        await ctx.send(f"Set show count to 0 for {number} questions.")#

    @command(
        name='standing',
        brief='Shows current standing for questions'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def standing(self,ctx : Context):
        q = Question.objects.filter(~Q(message_id=None), u__g=self.g, asked=False).order_by('-vote_count')
        table = Texttable()
        tabledata = [["Vote count","Question", "User", "Added", "Shown","Msg nr"]]
        for q_obj in q:
            tabledata.append([f"{q_obj.vote_count}",f'{q_obj.question}', f'{q_obj.u.d_name}'
                                 , f"{q_obj.time.strftime('%Y-%m-%d %H:%M')}", f'{q_obj.show_count}',f"{q_obj.msg_nr}"])

        table.set_deco(Texttable.VLINES | Texttable.HEADER | Texttable.BORDER)
        table.add_rows(tabledata, True)
        table.set_cols_width([10,30, 10, 17, 5,6])
        txt = "```" + table.draw() + "```"
        await send_table(ctx.send,txt)

    @command(
        name='show_count',
        brief='Sets the maximum number a question can show up for vote.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def show_count(self,ctx : Context, number : int):
        self.g.show_up_count = number
        self.g.save()
        await ctx.send(f"Set maximum number a question can show up to **{number}**")

    @command(
        name='show_answers',
        brief='Shows all current answers',
        help='Shows all current answers'
    )
    async def show_answers(self,ctx : Context):
        if not self.g.answering:
            await ctx.send("Currently not answering.")
            return

        q: Question = Question.objects.get(u__g=self.g, currently_asked=True)
        table = Texttable()
        tabledata = [["Time", "User", "answer"]]
        for a in Answer.objects.filter(question=q).order_by('time'):
            tabledata.append([a.time.strftime('%Y-%m-%d %H:%M'),a.u.d_name,a.answer])
        table.set_deco(Texttable.VLINES | Texttable.HEADER | Texttable.BORDER)
        table.add_rows(tabledata, True)
        table.set_cols_width([17 ,15, 50 ])
        txt = "```" + table.draw() + "```"
        await send_table(ctx.send,txt)

    @command(
        name='enable_ping',
        brief='Enables/Disables the pinging of here/role by the bot.',
        help='Enables/Disables the pinging of here/role by the bot. Users are still pinged when '
              'their questions show up. Use True/False for active'
    )
    async def enable_ping(self,ctx : Context,active : bool):
        self.g.enable_ping = active
        self.g.save()
        await ctx.send(f"Enable ping set to {active}")

    @command(
        name='question_limit',
        brief='Sets the question limit, meaning the amount of questions that will show up in the question channel.',
        help='Sets the question limit, meaning the amount of questions that will show up in the question channel. Must '
              'be a number greater than 1.'
    )
    async def question_limit(self,ctx : Context,questions : int):
        if questions < 1:
            await ctx.send("You must choose a number of questions greater than 1.")
            return
        self.g.question_limit = questions
        self.g.save()
        await ctx.send(f"Set question limit to {questions}")

    @command(
        name='anonymize_answering',
        brief='Enables/Disables the anonymizing of answers.',
        help='Enables/Disables the anonymizing of answers. You then need to use the answer command to answer to a '
             'question, normal typing is no longer available.'
    )
    async def anonymize_answering(self,ctx :Context, active : bool):
        self.g.anonymize_answering = active
        self.g.save()
        await ctx.send(f"Anonymize answering set to {active}")