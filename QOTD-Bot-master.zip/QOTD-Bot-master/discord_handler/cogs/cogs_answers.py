from discord.ext.commands import Cog,Bot,Context,command
from discord import Message, User,DMChannel,TextChannel
from BBase.discord.cog_interface import ICog,AuthorState
from db.models import Question,DBGuild, DBUser,Answer,Error
from discord.errors import *
from discord.ext.commands.errors import *
import traceback

class AnswerCmd(ICog):
    def __init__(self,bot : Bot):
        super().__init__(bot,AuthorState.User)

    async def cog_command_error(self, ctx: Context, error: CommandError):
        user: User = self.bot.get_user(ctx.author.id)
        dm_channel: DMChannel = await user.create_dm()
        g_id = ctx.guild.id if isinstance(ctx, Context) else ctx.id
        g_name = ctx.guild.name if isinstance(ctx, Context) else ctx.name
        try:
            g = DBGuild.objects.get(id=g_id)
        except DBGuild.DoesNotExist:
            g = DBGuild(id=g_id, name=g_name)
            g.save()

        if isinstance(error, CheckFailure):
            if isinstance(error,BotMissingPermissions):
                text = "To use this command, the bot needs the following permissions:\n"
                for i in error.missing_perms:
                    text += f"**- {i}**\n"
                text += "Please make sure that these are available to QOTDBot."
                await dm_channel.send(text)

                guild = ctx.guild
                me = guild.me if guild is not None else ctx.bot.user
                permissions = ctx.channel.permissions_for(me)

                e = Error(g=g, cmd_string=ctx.message.system_content
                          , error_type=f'{type(error)}', error=f'{error}', traceback=f"Has : "
                    f"{permissions}\n\nNeeds: {error.missing_perms}")
                e.save()
                await self.notify_error_bot_owner(e, ctx)
            else:
                await dm_channel.send('** Error **: You are not allowed to use this command!')
        elif isinstance(error, MissingRequiredArgument):
            await dm_channel.send(f"** Error **: Command _**{ctx.command.qualified_name}**_ misses some arguments."
                           f" See the help")

        elif isinstance(error, ConversionError):
            await dm_channel.send(f'** Error **: Cannot convert arguments for _**{ctx.command.qualified_name}**_. '
                           'Please make sure, you use the correct types. See the help')

        elif isinstance(error, BadArgument):
            await dm_channel.send(f'** Error **: Bad Argument for _**{ctx.command.qualified_name}**_! Please '
                           f'check help.')

        elif isinstance(error,Forbidden):
            text = f'** Error **: Permissions missing for the Bot. The bot needs at least\n'\
                   f'__Manage Roles__\n'\
                   f'__Manage Channels__\n'\
                   f'__Send Messages__\n'\
                   f'__Manage Messages__\n'\
                   f'__Attach files__\n'\
                   f'__Read message history__\n'\
                   f'__Add reactions__\n'\
                   f'Total integer value: 1342285904\n'\
                   f'Please make sure that these permissions are given to the bot.'

            await dm_channel.send(text)
            e = Error(g=g, cmd_string=ctx.message.system_content
                      , error_type=f'{type(error.original)}', error=f'{error}', traceback=traceback.format_exc())
            e.save()
            await self.notify_error_bot_owner(e, ctx)

        else:
            e = Error(g=g, cmd_string=ctx.message.system_content
                      , error_type=f'{type(error.original)}', error=f'{error}',traceback=traceback.format_exc())
            e.save()
            await self.notify_error_bot_owner(e, ctx)
            await dm_channel.send(f'Sorry an error occured. My creator has been notified.')

        await ctx.message.delete()

    @Cog.listener()
    async def on_message_delete(self,message : Message):
        if not isinstance(message.channel, TextChannel) or message.author.id == self.bot.user.id:
            return  # skip DMs here

        try:
            g = DBGuild.objects.get(id=message.guild.id)
        except DBGuild.DoesNotExist:
            g = DBGuild(id=message.guild.id, name=message.guild.name)
            g.save()

        if g.answer_channel is None or message.channel.id != g.answer_channel or not g.answering:
            return

        try:
            u = DBUser.objects.get(d_id=message.author.id, g=g)
        except DBUser.DoesNotExist:
            u = DBUser(d_id=message.author.id, d_name=message.author.display_name, g=g)
            u.save()

        user: User = self.bot.get_user(u.d_id)
        dm_channel: DMChannel = await user.create_dm()
        try:
            a = Answer.objects.get(message_id=message.id)
            a.delete()
        except Answer.DoesNotExist:
            pass

    @command(
        name='del_answer',
        brief='Deletes your last answer.',
        help='Answers a question. Only active when anonym answering is active.'
    )
    async def del_answer(self,ctx : Context):
        try:
            dm_channel: DMChannel = await ctx.author.create_dm()
        except AttributeError:
            await ctx.message.delete(delay=1)
            return

        g = self.g
        try:
            u = DBUser.objects.get(d_id=ctx.author.id, g=g)
        except DBUser.DoesNotExist:
            u = DBUser(d_id=ctx.author.id, d_name=ctx.author.display_name, g=g)
            u.save()

        try:
            q: Question = Question.objects.get(u__g=g, currently_asked=True)
        except Question.DoesNotExist:
            try:
                await ctx.message.delete(delay=1)
                await dm_channel.send("There is no question currently asked.")
            except Forbidden:
                pass
            return

        a = Answer.objects.get(question=q, u=u)
        channel : TextChannel = ctx.channel
        msg = await channel.fetch_message(a.message_id)
        await msg.delete()
        text = a.answer
        a.delete()
        await ctx.message.delete()
        try:
            await dm_channel.send(f"Deleted your last answer with: {text}")
        except Forbidden:
            pass
        return

    @command(
        name='answer',
        brief='Answers a question. Only active when anonym answering is active.',
        help='Answers a question. Only active when anonym answering is active.'
    )
    async def answer(self,ctx : Context,*,answer):
        g = self.g

        try:
            u = DBUser.objects.get(d_id=ctx.author.id, g=g)
        except DBUser.DoesNotExist:
            u = DBUser(d_id=ctx.author.id, d_name=ctx.author.display_name, g=g)
            u.save()

        if g.answer_channel is None:
           await ctx.send("Sorry, the answer channel is not setup.",delete_after=5)
           return

        if ctx.message.channel.id != g.answer_channel:
            await ctx.send("You need to answer in the answer channel.", delete_after=5)
            return

        user: User = self.bot.get_user(ctx.author.id)

        try:
            dm_channel: DMChannel = await user.create_dm()
        except AttributeError:
            await ctx.message.delete(delay=1)
            return

        q = await self.check_prerequisit(ctx.message,dm_channel,g,u)

        if q is None:
            return

        await ctx.message.delete()

        if not g.anonymize_answering:
            try:
                await dm_channel.send("Anonym answering is not active. Please simply type your answer in chat.")
            except Forbidden:
                pass
            return

        msg = await ctx.send(f'--------------------------\n{answer}\n--------------------------')

        a = Answer(question=q, answer=answer, u=u, message_id=msg.id)
        a.save()

        await msg.add_reaction('👍')
        try:
            await dm_channel.send(f"Successfully answered with \n**{answer}**\n"
                                  f"Use __{g.prefix}del_answer__ to delete your answer.")
        except Forbidden:
            pass

    @Cog.listener()
    async def on_message(self, message: Message):
        if not isinstance(message.channel, TextChannel) or message.author.id == self.bot.user.id:
            return  # skip DMs here

        try:
            g = DBGuild.objects.get(id=message.guild.id)
        except DBGuild.DoesNotExist:
            g = DBGuild(id=message.guild.id, name=message.guild.name)
            g.save()

        if message.content.startswith(f'{g.prefix}answer ') or message.content.startswith(f'{g.prefix}del_answer '):
            return

        if g.answer_channel is None or message.channel.id != g.answer_channel:
            return

        try:
            u = DBUser.objects.get(d_id=message.author.id, g=g)
        except DBUser.DoesNotExist:
            u = DBUser(d_id=message.author.id, d_name=message.author.display_name, g=g)
            u.save()

        user: User = self.bot.get_user(message.author.id)
        try:
            dm_channel: DMChannel = await user.create_dm()
        except AttributeError:
            await message.delete(delay=1)
            return

        if g.anonymize_answering:
            try:
                await message.delete(delay=1)
                await dm_channel.send(f"Anonym answering is active. Please use the __{g.prefix}answer__ "
                                      f"in the answering channel to answer the question.")
            except Forbidden:
                pass
            return

        q = await self.check_prerequisit(message,dm_channel,g,u)

        if q is None:
            return

        a = Answer(question=q, answer=message.content, u=u, message_id=message.id)
        a.save()

        await message.add_reaction('👍')

    async def check_prerequisit(self,message : Message,dm_channel : DMChannel, g : DBGuild,u : DBUser):
        try:
            q: Question = Question.objects.get(u__g=g, currently_asked=True)
        except Question.DoesNotExist:
            try:
                await message.delete(delay=1)
                await dm_channel.send("Now is not the time to answer questions. Please return later.")
            except Forbidden:
                pass
            finally:
                return None

        if not g.answering:
            await message.delete(delay=1)
            try:
                await dm_channel.send("Now is not the time to answer questions. Please return later.")
            except Forbidden:
                pass
            finally:
                return None

        if len(Answer.objects.filter(u=u, question=q)) != 0:
            await message.delete(delay=1)
            try:
                if g.anonymize_answering:
                    text = "Sorry you can only answer once. " \
                           f"You can delete your old message using __{g.prefix}del_answer__ though, " \
                            f"and submit a new one."
                else:
                    text = "Sorry you can only answer once. You can delete your old message though, " \
                           "and submit a new one."
                await dm_channel.send(text)
            except Forbidden:
                pass
            finally:
                return None

        return q
