from discord.ext.commands import command,Context, Bot,bot_has_permissions
from discord import Role,File,TextChannel
from django.db.models import Sum
from BBase.discord.cog_interface import ICog,AuthorState
from db.models import Question,DBUser, Answer
import asyncio
import re
from typing import Union
from django.db.models import Q
from pandas import DataFrame as df
import numpy as np
import matplotlib.pyplot as pl
from texttable import Texttable
from matplotlib.axes import Axes
import os
from discord_handler.meta import send_table

path = os.path.dirname(os.path.realpath(__file__)) + "/../../"

class Owner(ICog):
    def __init__(self,bot : Bot):
        super().__init__(bot,AuthorState.Owner)

    @command(
        name='set_prefix',
        help="Sets the prefix for the bot"
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def set_prefix(self, ctx: Context, prefix: str):
        self.g.prefix = prefix
        self.g.save()
        await ctx.send(f"**Prefix has ben set to _{self.g.prefix}_**")

    @command(
        name='add_mod',
        brief='Gives a user moderation privileges.',
        help='Gives a user moderation privileges. A flag is turned on for this user. He has then access to the Mod '
             'group of commands as seen in the help command.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def add_mod(self,ctx: Context, user_id: Union[int, str]):
        u, m = self.get_user(ctx, user_id)
        u.g_mod = False
        u.save()
        await ctx.send(f":white_check_mark:**User {m.mention if m is not None else u.d_name}({u.d_id}) "
                       f"is now a mod!**")

    @command(
        name='add_mod_role',
        brief='Gives users with this role moderation privileges.',
        help='Gives users with this role moderation privileges. All users that have this role will then be able to '
             'access the Mod group of commands as seen in the help command. If a role is already set, this '
             'method will not remove the old role, but rather both will then have moderation privileges.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def add_mod_role(self,ctx: Context, role_id: Union[int, Role]):
        if isinstance(role_id, int):
            role = ctx.guild.get_role(role_id)
        else:
            role = role_id

        if role is None:
            await ctx.send(f"Sorry, {role_id} is not available as a role on the guild.")
            return

        self.g.add_role(role_id)
        self.g.save()
        await ctx.send(f":white_check_mark:**Users with {role.mention}({role.id}) role are now mods**")

    @command(
        name='rm_mod_role',
        brief='Resets moderation role.',
        help='Removes **all** moderation roles that are set on the server. You can add new roles using add_mod_role '
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def rm_mod_role(self,ctx: Context):
        self.g.mod_role = None
        self.g.save()
        await ctx.send(f":red_circle:**Removed mod role**")

    @command(
        name='rm_mod',
        brief='Removes moderation privileges from the user',
        help='Removes moderation privileges from the user. This is only valid for the individual permissions, so if '
             'the user was given moderation privileges trough add_mod. If a mod role is set and he still has this '
             'role, he will still have moderation privileges!'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def rm_mod(self, ctx: Context, user_id: Union[int, str]):
        u,m = self.get_user(ctx,user_id)
        u.g_mod = False
        u.save()
        await ctx.send(f":red_circle:**User {m.mention if m is not None else u.d_name}({u.d_id}) "
                       f"is no longer a mod!**")

    def get_user(self,ctx : Context,u_id: Union[int, str]):

        m = None
        u_id = int(re.findall(r"\d+", u_id)[0]) if isinstance(u_id, str) else u_id

        for i in ctx.guild.members:
            if i.id == u_id:
                m = i
                break

        try:
            u = DBUser.objects.get(d_id=u_id, g=self.g)
        except DBUser.DoesNotExist:
            u = DBUser(d_id=u_id,g=self.g,d_name=m.display_name if m is not None else "")
            u.save()

        return u,m

    @command(
        name='show_updates',
        help="Enables/Disables messages from the QOTD-Bot devs. Use True/False for <val>"
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def show_updates(self, ctx: Context, val: bool):
        self.g.show_updates = val
        self.g.save()
        await ctx.send(f"**Show updates has been set to _{self.g.show_updates}_**")

    @command(
        name='set_logchannel',
        brief='Sets the log channel for QOTD-Bot',
        help='Sets the log channel for the QOTD-Bot. This log channel will be used for various updates from QOTD-Bot,'
             'including but not limited to: Expiration of reasons and consequences, user information for users that '
             'have punishments/consequences on other servers and bot messages. It is highly recommended to set this!'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def set_logchannel(self,ctx: Context, channel: Union[str, int]):
        ch_id = int(re.findall(r"\d+", channel)[0]) if isinstance(channel, str) else channel
        self.g.log_channel = ch_id
        self.g.save()
        ch = None
        for i in ctx.guild.channels:
            if i.id == ch_id:
                ch = i

        await ctx.send(f"Setting logchannel to {ch.mention} ({ch_id})")

    @command(
        name='set_channels',
        brief='Configures channels for QOTD Bot',
        help='Configues channels for QOTD Bot. Asks for question, answer and hall of fame channels to post in.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def set_channels(self,ctx : Context):
        setup_cog = self.bot.get_cog('Setup')
        try:
            await setup_cog.setup_question_channel(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await setup_cog.setup_answers_channel(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await setup_cog.setup_hof_channel(ctx)
        except asyncio.TimeoutError:
            return

    @command(
        name='shuffle_questions',
        alias=['shuffle','reorder'],
        brief='Recreates the questions that are next.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def shuffle_questions(self,ctx : Context):
        bot_questions = self.bot.get_cog('QuestionCmd')
        bot_questions.build_up_next_questions(self.g)
        await ctx.send("Shuffled up next questions.")

    @command(
        name='end_answering',
        brief='Ends the answering round'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def end_answering(self,ctx : Context):
        if not self.g.answering:
            await ctx.send("Answering is not currently in process. Can't stop whats not running.")
            return
        self.g.force_end_answering = True
        self.g.save()
        qcmd = self.bot.get_cog('QuestionCmd')
        await qcmd.action_crawler(ctx.guild)
        await ctx.send("Ended answering.")

    @command(
        name = 'run',
        brief='Starts/Stops the bot. Active is represented by either True or False.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True,
        add_reactions=True,
        read_message_history=True
    )
    async def run(self,ctx : Context,active : bool):
        if self.g.question_channel is None or self.g.answer_channel is None or self.g.hall_of_fame_channel is None:
            await ctx.send(f"No channels are setup for this server. Please use the __{self.g.prefix}setup__ "
                           f"command to setup your server.")
            return

        if self.g.run == active:
            await ctx.send(f"QOTDBot already {active}")
            return

        g = self.g

        if active:
            qcmd = self.bot.get_cog('QuestionCmd')
            g.run = True
            g.answering = False
            g.force_end_answering=False
            g.save()
            Question.objects.filter(u__g=g).update(message_id=None,msg_nr=None,currently_asked=False)
            await qcmd.action_crawler(ctx.guild)
            await ctx.send(f"QOTD started")
        else:
            g.run = False
            g.next_answer_round = None
            g.save()
            await ctx.send(f"QOTD ended")

    @command(
        name = 'qotd_role',
        brief = 'Sets the qotd role that is mentioned.',
        help = 'Sets the qotd role that is mentioned. You either need to mention the role or use the '
               'ID of the role as a parameter. You can also reset this behaviour (meaning @here is pinged), '
               'by setting it to None.'
    )
    @bot_has_permissions(
        send_messages=True,

    )
    async def qotd_role(self,ctx : Context, role : Union[int,Role,None]):
        if isinstance(role,int):
            role = ctx.guild.get_role(role)

        self.g.qotd_role = role.id
        self.g.save()
        await ctx.send(f"Set QOTD role to {role.mention}")

    @command(
        name='telemetry',
        brief='Shows telemetry information about the bot.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True,
        add_reactions=True,

        attach_files=True
    )
    async def telemetry(self,ctx : Context):
        q = Question.objects.filter(~Q(asked_time=None),u__g=self.g).order_by('asked_time')
        res_dict = {
            'asked_time':[],
            'question' : [],
            'time':[],
            'vote_count':[],
            'show_count':[],
            'answer_cnt':[],
            'answer_votes':[]
        }

        for q_obj in q:
            q_obj : Question
            res_dict['asked_time'].append(q_obj.asked_time)
            res_dict['question'].append(q_obj.question)
            res_dict['time'].append(q_obj.time)
            res_dict['vote_count'].append(q_obj.vote_count)
            res_dict['show_count'].append(q_obj.show_count)
            answers = Answer.objects.filter(question=q_obj)
            votes = answers.aggregate(Sum('vote_count'))['vote_count__sum']
            res_dict['answer_cnt'].append(len(answers))
            res_dict['answer_votes'].append(votes)

        res = df.from_dict(res_dict)
        text = f'**Telemetry for {ctx.guild.name}:**\n\n'
        text += f'__Total asked questions__: {len(res)}\n'
        text += f'__Total votes for questions__:{np.sum(res.vote_count)}\n'
        text += f'__Total answers given__: {np.sum(res.answer_cnt)}\n'
        text += f'__Total votes for answers__: {np.sum(res.answer_votes)}\n'
        text += f'__Available questions__ : {len(Question.objects.filter(u__g=self.g,asked_time=None,show_count__lte=self.g.show_up_count,asked=False))}\n'
        text += f'__Mean number of shows for a question to be answered__: {np.mean(res.show_count)}\n'

        await ctx.send(text)
        x_plot = np.arange(0,len(res))
        fig = pl.figure()
        ax: Axes = fig.add_subplot(111)
        ax.plot(x_plot, res.vote_count, color='green', linestyle='--', marker='o', label='growth')
        ax.set_xticks([])
        ax.set_title("Question vote count over time")
        p_vote = f"{path}plots/question_vote_plot.png"
        pl.tight_layout()
        pl.savefig(p_vote)
        await ctx.send(file=File(p_vote))

        fig = pl.figure()
        ax: Axes = fig.add_subplot(111)
        ax.plot(x_plot, res.answer_cnt, color='green', linestyle='--', marker='o', label='growth')
        ax.set_xticks([])
        ax.set_title("Answer count over time")
        p_answer = f"{path}plots/question_answer_plot.png"
        pl.tight_layout()
        pl.savefig(p_answer)
        await ctx.send(file=File(p_answer))

        table = Texttable()
        tabledata = [["id", "Asked time", "Question", "Votes", "Answers"]]
        for i in res.iterrows():
            s = i[1]
            tabledata.append([
                f'{i[0]}',
                f"{s.asked_time.strftime('%Y-%m-%d %H:%M')}",
                f'{s.question}',
                f'{s.vote_count}',
                f'{s.answer_cnt}',
            ])
        table.set_deco(Texttable.VLINES | Texttable.HEADER | Texttable.BORDER)
        table.add_rows(tabledata, True)
        table.set_cols_width([3, 17, 30, 5, 7])
        txt = "```" + table.draw() + "```"
        await ctx.send(txt)

        os.remove(p_answer)
        os.remove(p_vote)