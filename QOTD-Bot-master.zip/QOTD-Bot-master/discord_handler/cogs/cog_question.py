from discord.ext.commands import command,Context,Cog,Bot,bot_has_permissions
from discord import Message,User,DMChannel,TextChannel,Guild,Reaction, Role
from django.db.models import Max,Q,F
import asyncio
from pandas import DataFrame as df

from django.utils import timezone
from BBase.discord.cog_interface import ICog,AuthorState
from db.models import Question,DBGuild, DBUser,Answer,Error
from discord.ext import tasks
from discord.errors import *
from datetime import timedelta
from typing import List
from discord.ext.commands.errors import *
import traceback
from discord_handler.meta import send_table
from BotIntercom.commands import send_qotd_request

class QuestionCmd(ICog):
    def __init__(self,bot : Bot):
        super().__init__(bot,AuthorState.User)
        self.questions_task.start()

    async def cog_command_error(self, ctx: Context, error: CommandError):
        user: User = self.bot.get_user(ctx.author.id)
        dm_channel: DMChannel = await user.create_dm()
        g_id = ctx.guild.id if isinstance(ctx, Context) else ctx.id
        g_name = ctx.guild.name if isinstance(ctx, Context) else ctx.name
        try:
            g = DBGuild.objects.get(id=g_id)
        except DBGuild.DoesNotExist:
            g = DBGuild(id=g_id, name=g_name)
            g.save()

        if isinstance(error, CheckFailure):
            if isinstance(error,BotMissingPermissions):
                text = "To use this command, the bot needs the following permissions:\n"
                for i in error.missing_perms:
                    text += f"**- {i}**\n"
                text += "Please make sure that these are available to QOTDBot."
                await dm_channel.send(text)

                guild = ctx.guild
                me = guild.me if guild is not None else ctx.bot.user
                permissions = ctx.channel.permissions_for(me)

                e = Error(g=g, cmd_string=ctx.message.system_content
                          , error_type=f'{type(error)}', error=f'{error}', traceback=f"Has : "
                    f"{permissions}\n\nNeeds: {error.missing_perms}")
                e.save()
                await self.notify_error_bot_owner(e, ctx)
            else:
                await dm_channel.send('** Error **: You are not allowed to use this command!')
        elif isinstance(error, MissingRequiredArgument):
            await dm_channel.send(f"** Error **: Command _**{ctx.command.qualified_name}**_ misses some arguments."
                           f" See the help")

        elif isinstance(error, ConversionError):
            await dm_channel.send(f'** Error **: Cannot convert arguments for _**{ctx.command.qualified_name}**_. '
                           'Please make sure, you use the correct types. See the help')

        elif isinstance(error, BadArgument):
            await dm_channel.send(f'** Error **: Bad Argument for _**{ctx.command.qualified_name}**_! Please '
                           f'check help.')

        elif isinstance(error,Forbidden):
            text = f'** Error **: Permissions missing for the Bot. The bot needs at least\n'\
                   f'__Manage Roles__\n'\
                   f'__Manage Channels__\n'\
                   f'__Send Messages__\n'\
                   f'__Manage Messages__\n'\
                   f'__Attach files__\n'\
                   f'__Read message history__\n'\
                   f'__Add reactions__\n'\
                   f'Total integer value: 1342285904\n'\
                   f'Please make sure that these permissions are given to the bot.'

            await dm_channel.send(text)
            e = Error(g=g, cmd_string=ctx.message.system_content
                      , error_type=f'{type(error.original)}', error=f'{error}', traceback=traceback.format_exc())
            e.save()
            await self.notify_error_bot_owner(e, ctx)

        else:
            e = Error(g=g, cmd_string=ctx.message.system_content
                      , error_type=f'{type(error.original)}', error=f'{error}',traceback=traceback.format_exc())
            e.save()
            await self.notify_error_bot_owner(e, ctx)
            await dm_channel.send(f'Sorry an error occured. My creator has been notified.')

        await ctx.message.delete()

    @command(
        name='ask',
        brief='Pose a question for QOTD.',
        help='Poses a question for QOTD. This needs to be posted in the questions channel for QOTDBot and '
             'will only be accepted if QOTD is up for questions. You can also only ask one question per round, '
             'but if your question is not chosen, it will reappear in the next round automatically.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True
    )
    async def ask(self,ctx :Context,*,q):
        g = self.g
        u = self.u
        m = self.m

        if not self.g.run:
            await ctx.send(f"Bot not started. Use {self.g.prefix}run.")
            return

        if g.question_channel is None:
            await ctx.send(f"No channels setup. Use {self.g.prefix}setup or {self.g.prefix}set_channels.")
            return

        channel: TextChannel = ctx.guild.get_channel(g.question_channel)
        msg: Message = ctx.message
        user: User = self.bot.get_user(u.d_id)
        dm_channel: DMChannel = await user.create_dm()

        if ctx.channel.id != g.question_channel:
            try:
                await dm_channel.send(f"Sorry, the asking of questions is only allowed in {channel.name}")
            except Forbidden:
                pass
            return

        await msg.delete(delay=1)

        if g.block_input:
            try:
                await dm_channel.send(f"QOTDBot is currently processing. Please try again a little bit later.")
            except Forbidden:
                pass
            return

        if u.asked:
            try:
                await dm_channel.send(f"Sorry, you already asked a question this round. You can add one "
                                      f"next time")
            except Forbidden:
                pass
            return

        if not q.endswith("?"):
            try:
                await dm_channel.send(f"Sorry the question \n\n**{q}**\n\n needs to end with a question mark")
            except Forbidden:
                pass
            return

        if len(Question.objects.filter(question=q)) != 0:
            try:
                await dm_channel.send(f"Sorry the question \n\n**{q}**\n\n has already been asked.")
            except Forbidden:
                pass
            return

        q_obj = Question(question=q, u=u)
        q_obj.save()
        u.asked = True
        u.save()

        try:
            await dm_channel.send(f"Your question: \n\n **{q_obj.question}**\n\n has been submitted successfully!")
        except Forbidden:
            pass

    @command(
        name='vote',
        brief='Votes for a question posed for QOTD.',
        help='Votes for a question posed for QOTD. You can only vote in the question channel of QOTDBot. '
             'You can also not vote for your own questions and you can only vote once per round.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True
    )
    async def vote(self, ctx : Context, question_nr : int):
        g = self.g
        u = self.u
        if not self.g.run:
            await ctx.send(f"Bot not started. Use {self.g.prefix}run.")
            return

        if g.question_channel is None:
            await ctx.send(f"No channels setup. Use {self.g.prefix}setup or {self.g.prefix}set_channels.")
            return

        channel: TextChannel = ctx.guild.get_channel(g.question_channel)
        msg: Message = ctx.message
        user: User = self.bot.get_user(u.d_id)
        dm_channel: DMChannel = await user.create_dm()

        if ctx.channel.id != g.question_channel:
            try:
                await dm_channel.send(f"Sorry, the voting of questions is only allowed in {channel.name}")
            except Forbidden:
                pass
            return

        await msg.delete(delay=1)

        if g.answering:
            try:
                await dm_channel.send(f"During answering it is not possible vote on questions. Please try later.")
            except Forbidden:
                pass
            return

        if u.nr_votes <=0:
            try:
                await dm_channel.send(f"You exhausted your number of votes possible. You can get another one by "
                                      f"voting for QOTDBot at\n\nhttps://discordbots.org/bot/595537041731747884")
            except Forbidden:
                pass
            return

        try:
            q = Question.objects.get(u__g=g, msg_nr=question_nr, asked=False)
            if q.u == u:
                await dm_channel.send(f"Sorry, you can not vote on your own question")
                return

            q.vote_count +=1
            q.save()
            u.voted = True
            u.nr_votes -=1
            u.save()
            try:
                await dm_channel.send(f"You have successfully voted for: \n\n __**{q.question}**__\n\n"
                                      f"If you want to have another one, consider voting for QOTDBot at"
                                      f"\n\nhttps://discordbots.org/bot/595537041731747884")
            except Forbidden:
                pass

        except Question.DoesNotExist:
            try:
                await dm_channel.send(f"Sorry, question with number {question_nr} is not available.")
            except Forbidden:
                pass
            return
        except Question.MultipleObjectsReturned:
            try:
                await dm_channel.send(f"Multiple questions were found with this number. This should not happen.")
            except Forbidden:
                pass
            return

    @Cog.listener()
    async def on_message(self,message : Message):
        if not isinstance(message.channel, TextChannel) or message.author.id == self.bot.user.id:
            return  # skip DMs here

        try:
            g = DBGuild.objects.get(id=message.guild.id)
        except DBGuild.DoesNotExist:
            g = DBGuild(id=message.guild.id, name=message.guild.name)
            g.save()

        if g.question_channel is None or message.channel.id != g.question_channel:
            return

        cmds = [i.name + " " for i in self.get_commands()]
        for i in cmds:
            if message.content.startswith(f"{g.prefix}{i}"):
                return
        channel: TextChannel = message.guild.get_channel(g.question_channel)
        user: User = self.bot.get_user(message.author.id)
        dm_channel: DMChannel = await user.create_dm()
        try:
            await dm_channel.send(f"Sorry, the question channel {channel.name} is only used for "
                                  f"asking questions and voting. You "
                                  "are not allowed to type there.")
        except Forbidden:
            pass
        await message.delete(delay=1)

    async def send_message_with_ping(self, g : DBGuild, d_g : Guild, ch : TextChannel, text : str):
        if g.qotd_role is not None:
            qotd_role :Role = d_g.get_role(g.qotd_role)
            old_mentionable = qotd_role.mentionable
            try:
                await qotd_role.edit(mentionable=True,reason="Pingable qotd role for announcement")
                mention = qotd_role.mention
            except:
                mention = "@here"
        else:
            mention = "@here"

        if g.enable_ping:
            text= f"{mention}: {text}"
        else:
            text = f"{text}"
        await send_table(ch.send,text,False)

        if g.qotd_role is not None:
            qotd_role :Role = d_g.get_role(g.qotd_role)
            try:
                await qotd_role.edit(mentionable=old_mentionable,reason="Set Pingable to old")
            except:
                pass

    def set_next_planned_answer(self,g : DBGuild):
        now = timezone.now()
        date = now + timedelta(days=1)
        date = date.replace(hour=g.answer_start_time.hour, minute=g.answer_start_time.minute, second=0, microsecond=0)
        g.next_answer_round = date
        g.save()

    def build_up_next_questions(self,g : DBGuild):
        # Part of guild, not asked yet, shown up less then equal 3 times, and no msg id (meaning not currently up for
        #vote)
        q = Question.objects.filter(u__g=g,asked=False,show_count__lte=g.show_up_count,message_id=None).order_by('?')[:g.question_limit].values('id')
        q = Question.objects.filter(pk__in=q)

        #safety update, all other to up_next False
        Question.objects.filter(u__g=g,up_next=True).update(up_next=False)
        q.update(up_next=True)

        return q

    async def change_questions(self,d_g : Guild,g : DBGuild):
        q_channel_id = g.question_channel
        q_channel : TextChannel = d_g.get_channel(q_channel_id)

        g.refresh_from_db()
        g.block_input = True
        g.save()


        len_messages = -1
        while len_messages != 0:
            len_messages = len(await q_channel.purge())

        old_questions = Question.objects.filter(u__g=g)
        old_questions.update(message_id = None, msg_nr=None)

        if len(Question.objects.filter(u__g=g, up_next=True)) < g.question_limit:
            self.build_up_next_questions(g)

        for i,q_obj in enumerate(Question.objects.filter(u__g=g,up_next=True)):
            m = d_g.get_member(q_obj.u.d_id)
            if m is None or not q_obj.u.ping:
                m = q_obj.u.d_name
            else:
                m = m.mention
            q_obj.msg_nr = i + 1

            msg = await send_table(q_channel.send,f"**Question {q_obj.msg_nr})** by {m}:\n{q_obj.question}",False)

            q_obj.message_id = msg.id
            q_obj.show_count = q_obj.show_count + 1
            q_obj.save()
            await asyncio.sleep(0.5)

        text= f" Questions are up for vote. Use __**{g.prefix}vote**__ to vote for the question you like." \
            f" You can also ask new questions using __**{g.prefix}ask**__.\n" \
            f"Next answering round is planned to start at {g.next_answer_round.strftime('%d.%m %H:%M')}(UTC)"
        await self.send_message_with_ping(g, d_g, q_channel, text)

        DBUser.objects.filter(g=g, asked=True).update(asked=False)
        DBUser.objects.filter(g=g, voted=True).update(nr_votes=F('nr_votes') + 1)
        DBUser.objects.filter(g=g, voted=True).update(voted=False)

        g.block_input = False
        g.save()

    async def process_end_answer(self,g : DBGuild, d_g :Guild, a_channel : TextChannel):
        g.force_end_answering = False
        g.block_input = True
        g.save()
        try:
            try:
                q: Question = Question.objects.get(u__g=g, currently_asked=True)
            except Question.DoesNotExist:
                # TODO errorhandling
                g.run = True
                g.save()
                g.answering = False
                Question.objects.filter(u__g=g).update(message_id=None, msg_nr=None, currently_asked=False)
                return

            for a in Answer.objects.filter(question=q):
                msg: Message = await a_channel.fetch_message(a.message_id)
                reactions: List[Reaction] = msg.reactions
                for r in reactions:
                    if r.emoji == '👍':
                        react_users = await r.users().flatten()
                        react_users = [u.id for u in react_users if u.id not in [a.u.d_id, self.bot.user.id]]
                        a.vote_count = len(react_users)
                        a.save()

            howler_result = {'player_d_id':[],'player_position':[]}

            for i, a in enumerate(Answer.objects.filter(question=q).order_by('-vote_count')):
                a : Answer
                a.place = i + 1
                howler_result['player_d_id'].append(a.u.d_id)
                howler_result['player_position'].append(i+1)
                try:
                    a.save()
                except Answer.DoesNotExist:
                    return

            if g.howler_integration:
                try:
                    send_qotd_request(df.from_dict(howler_result),q.u.d_id,d_g.id,d_g.name)
                except:
                    pass

            try:
                a = Answer.objects.get(question=q, place=1)
            except Answer.DoesNotExist:
                return
            text = f"And this concludes the answering round for this time. The most popular " \
                f"answer was by **{a.u.d_name}** with **{a.vote_count} votes**:\n\n " \
                f"{a.answer}\n\n" \
                f"The next question round will start soon."
            await self.send_message_with_ping(g, d_g, a_channel, text)

            if g.hall_of_fame_channel is not None:
                hof_channel: TextChannel = d_g.get_channel(g.hall_of_fame_channel)

                try:
                    d_g: Guild = [i for i in self.bot.guilds if i.id == q.u.g.id][0]
                    user = d_g.get_member(q.u.d_id)
                    if user is not None and a.u.ping:
                        user = user.mention
                    else:
                        user = a.u.d_name
                except KeyError:
                    user = a.u.d_name

                text = f"__**{q.question}** by {user}__:\n\n"
                for a in Answer.objects.filter(question=q, place__lte=3).order_by('place'):
                    try:
                        d_g: Guild = [i for i in self.bot.guilds if i.id == a.u.g.id][0]
                        user = d_g.get_member(a.u.d_id)
                        if user is not None and a.u.ping:
                            user = user.mention
                        else:
                            user = a.u.d_name
                    except KeyError:
                        user = a.u.d_name
                    text += f"**{a.place}. Place**({a.vote_count} votes):\n_{user}:_ **{a.answer}**\n"
                await send_table(hof_channel.send,text,False)

            await self.change_questions(d_g, g)

            q.currently_asked = False
            q.save()

            self.set_next_planned_answer(g)
            q_list = self.build_up_next_questions(g)
            if len(q_list) is None:
                g.next_answer_round = None
            g.answering = False
            g.save()
        except Exception as e:
            raise e
        finally:
            g.block_input = False
            g.save()

    async def action_crawler(self, d_g : Guild):
        """
        Task loop, that handles the current state of the bot. TODO more documentation!
        :param d_g: Guild that needs to be checked
        """
        g = DBGuild.objects.get(id=d_g.id)
        g.refresh_from_db()

        if not g.run:
            return

        q_channel : TextChannel = d_g.get_channel(g.question_channel)
        a_channel : TextChannel = d_g.get_channel(g.answer_channel)

        if q_channel is None or a_channel is None:
            return

        if g.next_answer_round == None:
            q_list = self.build_up_next_questions(g)
            if len(q_list) == 0:
                len_messages = -1
                while len_messages != 0:
                    len_messages = len(await q_channel.purge())
                DBUser.objects.filter(g=g, asked=True).update(asked=False)
                await q_channel.send(f"No questions are available yet. "
                                     f"You can ask questions with __**{g.prefix}ask**__")
                return
            self.set_next_planned_answer(g)
            await self.change_questions(d_g,g)
            self.build_up_next_questions(g)
            if len(Question.objects.filter(~Q(message_id=None), u__g=g, asked=False)) == 0:
                await self.change_questions(d_g,g)
                self.build_up_next_questions(g)

        now = timezone.now()
        if g.next_answer_round < now < (g.next_answer_round + timedelta(seconds=g.answer_duration)) and not g.force_end_answering:
            if g.answering:
                if len(Question.objects.filter(u__g=g,up_next=True)) < g.question_limit:
                    self.build_up_next_questions(g)
                return

            g.block_input = True
            g.save()
            try:
                g.answering = True
                len_messages = -1
                while len_messages != 0:
                    len_messages = len(await a_channel.purge())

                v_count = \
                    Question.objects.filter(~Q(message_id=None), u__g=g, asked=False).aggregate(Max('vote_count'))[
                        'vote_count__max']
                q = Question.objects.filter(~Q(message_id=None), u__g=g, asked=False, vote_count=v_count).order_by('?')

                if len(q) > 0:
                    q = q[0]
                    q.currently_asked = True
                    q.asked_time = timezone.now()
                    q.asked = True

                    m = d_g.get_member(q.u.d_id)
                    if m is None or not q.u.ping:
                        m = q.u.d_name
                    else:
                        m = m.mention
                    DBUser.objects.filter(g=g, asked=True).update(asked=False)
                    text = f"The answering round has started. The most voted question was:\n\n " \
                        f"__**Question nr {q.msg_nr}: {q.question}**__\n\n " \
                        f"from {m} with {q.vote_count} votes.\n " \
                        f"You can answer this question now if you like. Remember, you can only " \
                        f"answer once. Also upvote the answer you like most, using the 👍 emoji."

                    if g.anonymize_answering:
                        text += f"\n**Anonym answering is active. use __{g.prefix}answer__ to " \
                            f"answer and __{g.prefix}del_answer__ to delete an already given answer**"
                    Question.objects.filter(~Q(id=q.id)).update(currently_asked=False)
                    q.save()
                    await self.send_message_with_ping(g, d_g, a_channel, text)

                    g.answering = True
                else:
                    g.answering = False
            except Exception as e:
                raise e
            finally:
                g.block_input = False
                g.save()

        else:
            if not g.answering:
                if len(Question.objects.filter(u__g=g, up_next=True)) < g.question_limit:
                    self.build_up_next_questions(g)
                return
            await self.process_end_answer(g,d_g,a_channel)


    @tasks.loop(minutes=1)
    async def questions_task(self):
        print("Crawler task checking ...")
        for d_g in self.bot.guilds:
            await self.action_crawler(d_g)

    @questions_task.before_loop
    async def before_questions_task(self):
        print('Crawler task waiting for ready...')
        await self.bot.wait_until_ready()
        print("Crawler task starting!")

    @questions_task.after_loop
    async def after_questions_task(self):
        print('Crawler task stopped, restarting!')
        await asyncio.sleep(10)
        self.questions_task.restart()
        print("Crawler task starting!")