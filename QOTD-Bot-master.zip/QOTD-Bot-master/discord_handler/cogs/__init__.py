from discord_handler.cogs.cogs_owner import Owner
from discord_handler.cogs.cog_question import QuestionCmd
from discord_handler.cogs.cogs_setup import Setup
from discord_handler.cogs.cogs_mod import Mod
from discord_handler.cogs.cogs_bot_owner import BotOwner
from discord_handler.cogs.cogs_answers import AnswerCmd
from discord_handler.cogs.cogs_all import All