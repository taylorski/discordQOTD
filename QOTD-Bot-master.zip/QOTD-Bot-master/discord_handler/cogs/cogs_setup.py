from discord.ext.commands import command,Context, Bot,bot_has_permissions
from discord import Message,Member, Reaction
from discord.errors import *
from BBase.discord.cog_interface import ICog,AuthorState
from db.models import DBGuild
import asyncio

class Setup(ICog):
    def __init__(self,bot : Bot):
        super().__init__(bot,AuthorState.Owner)

    async def wait_for(self,ctx : Context,event : str, check : callable, timeout):
        try:
            return await ctx.bot.wait_for(event,check=check,timeout=timeout)
        except asyncio.TimeoutError:
            try:
                await ctx.send("Sorry, you timed out.")
            except Forbidden:
                pass
            return None

    async def setup_prefix(self,ctx :Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        await ctx.send("By default, QOTD-Bot uses __**?**__ as a prefix. This is a very common prefix. If you like"
                       "a different one, simply type in the prefix you like now. If you are fine with __**?**__,"
                       "simply type this prefix.")

        def log_channel_check(m : Message):
            return m.author == ctx.author and m.channel == ctx.channel

        msg : Message = await self.wait_for(ctx,'message',log_channel_check,300)
        if msg is None:
            raise asyncio.TimeoutError

        self.g.prefix = msg.content
        self.p = self.g.prefix
        self.g.save()
        await ctx.send(f"Prefix set to **{self.g.prefix}**. You can change this later with {self.g.prefix}set_prefix.")

    async def setup_mod_role(self,ctx:Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        msg = await ctx.send("There are three ways QOTD-Bot identifies Moderators on a server:\n"
                       "1) All users who have the right to ban people\n"
                       "2) All users with the according mod role\n"
                       "3) All users that are set manually to be a mod.\n\n"
                       f"You can set the according mod role using __**{self.p}add_mod_role @mod_role**__ and"
                       f"give an individual user mod rights using __**{self.p}add_mod @mention_user**__\n\n"
                       "You can add mods right now using these commands. React to this message with 	✅"
                       " when you are done.")

        def check_user_message(reaction: Reaction, user: Member):
            return reaction.message.id == msg.id and user == ctx.author and reaction.emoji =='✅'

        await msg.add_reaction('✅')
        try:
            return await ctx.bot.wait_for('reaction_add',check=check_user_message,timeout=200)
        except asyncio.TimeoutError:
            await ctx.send("Sorry, you timed out.")
            raise asyncio.TimeoutError


    async def setup_log_channel(self,ctx :Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        await ctx.send("_QOTD-Bot needs a logging channel. This channel will be used "
                       "to send updates on punishments and consequences, as well as other things if they are"
                       " configured._\n"
                       "**Please type in the name of the channel QOTD-Bot will use for logs, using #**")

        def log_channel_check(m : Message):
            return m.author == ctx.author and m.channel == ctx.channel and len(m.channel_mentions)==1

        msg : Message = await self.wait_for(ctx,'message',log_channel_check,300)
        if msg is None:
            raise asyncio.TimeoutError

        channel = msg.channel_mentions[0].id
        self.g.log_channel = channel
        self.g.save()
        await ctx.send(f"Channel set to **{msg.channel_mentions[0].mention}**.")

    async def setup_channel(self,ctx :Context, send_text : str, ):
        await ctx.send(send_text)

        def log_channel_check(m : Message):
            return m.author == ctx.author and m.channel == ctx.channel and len(m.channel_mentions)==1

        msg : Message = await self.wait_for(ctx,'message',log_channel_check,300)
        if msg is None:
            return None

        await ctx.send(f"Channel set to **{msg.channel_mentions[0].mention}**.")
        return msg.channel_mentions[0].id

    async def setup_question_channel(self,ctx :Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        text = "The bot needs a **question** channel, where he can post the listed questions. Please mention " \
               "the according channel using #.\n" \
               "**Be aware that this channel will be purged by the bot. Only the questions will be visible there." \
               " It is recommended to setup a new channel for this.**"
        channel = await self.setup_channel(ctx,text)
        self.g.question_channel = channel
        self.g.save()

    async def setup_answers_channel(self,ctx :Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        text = "The bot needs a **answers** channel, where people post their answers to a given question. " \
               "Please mention the according channel using #.\n" \
               "**Be aware that this channel will be purged by the bot. Only the answers during answering time will be visible there." \
               "  It is recommended to setup a new channel for this.**"
        channel = await self.setup_channel(ctx,text)
        self.g.answer_channel = channel
        self.g.save()

    async def setup_hof_channel(self,ctx :Context):
        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()
        text = "The bot needs a **Hall of fame** channel, where the best answers are posted. " \
               "Please mention the according channel using #."
        channel = await self.setup_channel(ctx,text)
        self.g.hall_of_fame_channel = channel
        self.g.save()

    @command(
        name='setup',
        brief='Performs the setup of the bot.'
    )
    @bot_has_permissions(
        send_messages=True,
        manage_messages=True,
        read_messages=True,
        add_reactions=True
    )
    async def setup(self,ctx : Context):
        await ctx.send("_Hi there. Lets set up QOTD-Bot!_")
        await asyncio.sleep(2)

        try:
            self.g =DBGuild.objects.get(id=ctx.guild.id)
        except DBGuild.DoesNotExist:
            self.g = DBGuild(id=ctx.guild.id, name=ctx.guild.name)
            self.g.save()

        try:
            await self.setup_prefix(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await self.setup_log_channel(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await self.setup_mod_role(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await self.setup_question_channel(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await self.setup_answers_channel(ctx)
        except asyncio.TimeoutError:
            return

        try:
            await self.setup_hof_channel(ctx)
        except asyncio.TimeoutError:
            return

        await ctx.send("And thats it. Check the help command for more information. The command is also "
                       "available on any individual command.\n\n"
                       f"To start QOTD, type __**{self.g.prefix}run True**__. The bot will then do "
                       f"a notification in your questions channel, that questions are now open. Users "
                       f"can then add questions using __**{self.g.prefix}ask**__, and after the "
                       f"question period, they can vote using __**{self.g.prefix}vote**__. The "
                       f"bot will ping the channels accordingly.\n\n"
                       "If you need any further help, you can join the support server. We try to be helpful there."
                       "Simply message QOTDBot with __**server_invite**__, to get an invitation to the support"
                       " server."
                       )