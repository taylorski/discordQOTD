from discord.ext.commands import command,Context, Bot,bot_has_permissions
from discord import User,DMChannel
from django.utils import timezone
from datetime import timedelta

from BBase.discord.cog_interface import ICog,AuthorState
from db.models import Question, Answer
from discord.errors import *
from discord_handler.meta import pretty_time,send_table

import logging
logger = logging.getLogger(__name__)

class All(ICog):
    def __init__(self, bot : Bot):
        super().__init__(bot,AuthorState.User)

    @command(
        name='ping_me',
        brief = 'Sets you pinging status.',
        help='Sets you pinging status. If you set this to False, the bot wont ping you'
    )
    @bot_has_permissions(
        send_messages=True
    )
    async def ping_me(self,ctx : Context,ping : bool):
        self.u.ping = ping
        self.u.save()
        await ctx.send(f"Set your ping to {'active' if ping else 'inactive'}")

    @command(
        name='me',
        brief='Shows some stats about the user that is calling the command.'
    )
    @bot_has_permissions(
        send_messages=True,
        attach_files=True,
        read_messages=True
    )
    async def me(self,ctx: Context):
        user: User = self.bot.get_user(ctx.author.id)
        dm_channel: DMChannel = await user.create_dm()
        answers = Answer.objects.filter(u=self.u)
        questions = Question.objects.filter(u=self.u)
        text = f"**Stats for {ctx.author.mention}**:\n\n"
        text += f":ballot_box: __Votes available:__ {self.u.nr_votes}\n"
        text += f":grey_question: __Total questions:__ {len(questions)}\n"
        text += f":question:__Questions that were answered:__ {len(questions.filter(u=self.u,asked=True))}\n"
        text += f":grey_exclamation:__Total answers:__ {len(answers)}\n"
        text += f":exclamation: __Best answer:__ " \
            f"```{None if len(answers)==0 else answers.order_by('-vote_count')[0].answer}``` " \
            f"(votes: {0 if len(answers)==0 else answers.order_by('-vote_count')[0].vote_count}) for " \
            f"```{None if len(answers)==0 else answers.order_by('-vote_count')[0].question.question}```\n"
        text += f":first_place: __Total answers that were on first place__: {len(answers.filter(place=1))}\n"
        text += f":second_place: __Total answers that were on second place__: {len(answers.filter(place=2))}\n"
        text += f":third_place: __Total answers that were on third place__: {len(answers.filter(place=3))}\n"
        try:
            await send_table(ctx.send,text,False)
        except Forbidden:
            await send_table(dm_channel.send, text, False)

    @command(
        name='time_left',
        brief='Time left until the next answering round.'
    )
    @bot_has_permissions(
        send_messages=True,
    )
    async def time_left(self,ctx: Context):
        if self.g.next_answer_round is None:
            await ctx.send("Bot is not started yet.")
            return

        now = timezone.now()
        date = timezone.now()
        date = date.replace(hour=self.g.next_answer_round.hour, minute=self.g.next_answer_round.minute, second=0, microsecond=0)
        if self.g.answering:
            date = date + timedelta(seconds=self.g.answer_duration)
            left = (date - now).total_seconds()
            await ctx.send(f"There is still {pretty_time(left)} left for answering.")
        else:
            if date < now:
                left = (date + timedelta(days=1) - now).total_seconds()
            else:
                left = (date - now).total_seconds()
            await ctx.send(f"There is still {pretty_time(left)} left until next answering round.")
