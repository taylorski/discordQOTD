from django.db import models
from django.utils import timezone
from datetime import time

class CurrentAction:
    not_running = None
    start = 0
    questions_round = 1
    questions_vote = 2
    answer_round= 3
    @staticmethod
    def action_name(action : int):
        if action == CurrentAction.not_running:
            return "Not running"
        elif action == CurrentAction.start:
            return "Start"
        elif action == CurrentAction.questions_round:
            return "Question round"
        elif action == CurrentAction.questions_vote:
            return "Question vote"
        elif action == CurrentAction.answer_round:
            return "Answer round"

class DBGuild(models.Model):
    id = models.IntegerField(verbose_name="Guild id",primary_key=True)
    prefix = models.CharField(max_length=10, verbose_name="Prefix for guild", default="?")
    name = models.CharField(max_length=256,verbose_name="Name of server")
    mod_role = models.CharField(max_length=512, verbose_name="Role id of mods", null=True,default=None)
    log_channel = models.IntegerField(verbose_name="Channel for logging", null=True,default=None)

    question_channel = models.IntegerField(verbose_name="ID of channel where questions will be voted on.",null=True,default=None)
    answer_channel = models.IntegerField(verbose_name="ID of channel where questions will be asked.",null=True,default=None)
    hall_of_fame_channel = models.IntegerField(verbose_name="ID of channel where the hall of fame will be posted.",null=True,default=None)

    show_updates = models.BooleanField(verbose_name="Show updates in logchannel", default=True)

    run = models.BooleanField(verbose_name="Bot running for guild",default=False)
    answer_start_time = models.TimeField(verbose_name="Time of the day, when answers are starting.",default=time(hour=18))
    answer_duration = models.IntegerField(verbose_name="Lenght of answering time",default=7200)
    answering = models.BooleanField(verbose_name="Answer round currently running",default=False)
    next_answer_round = models.DateTimeField(verbose_name="Date and time of next answering round.",default=None,null=True)
    time_stamp = models.DateTimeField(verbose_name="Date of adding the guild", default=timezone.now)

    qotd_role = models.IntegerField(verbose_name="Id of qotd rule.",default=None,null=True)

    block_input = models.BooleanField(verbose_name="Block all input in answer and question channels",default=False)
    show_up_count = models.IntegerField(verbose_name="Maximum number of shows for a given question",default=3)
    force_end_answering = models.BooleanField(verbose_name="End Answering NOW",default=False)
    enable_ping = models.BooleanField(verbose_name="Ping enabled, either via role or here",default=True)
    question_limit = models.IntegerField(verbose_name="Number of questions that will show up.",default=5)
    anonymize_answering = models.BooleanField(verbose_name="Enables/Disables anonym answering mode",default=False)
    howler_integration = models.BooleanField(verbose_name="Howler integration of QOTD",default=False)

    def __repr__(self):
        return f"{self.id}:{self.name}"

    def __str__(self):
        return self.__repr__()

    def m_role(self):
        if self.mod_role is not None:
            return [int(i) for i in self.mod_role.split(";")]
        else:
            return None

    def add_role(self,role):
        if self.mod_role is not None:
            self.mod_role += f";{role}"
        else:
            self.mod_role = f"{role}"

    def rm_role(self,role):
        if f"{role}" in self.mod_role and f"{role}" != self.mod_role:
            self.mod_role = self.mod_role.replace(f";{role}","")
        elif f"{role}" == self.mod_role:
            self.mod_role = None

class DBUser(models.Model):
    d_id = models.IntegerField(verbose_name="User id, discord")
    d_name = models.CharField(max_length=64,verbose_name="Name on server",default="")
    g = models.ForeignKey(DBGuild, verbose_name="ID of server", on_delete=models.CASCADE)
    g_mod = models.BooleanField(verbose_name="Mod flag", default=False)

    nr_votes = models.IntegerField(verbose_name="Total number of votes left for a user",default=1)
    voted = models.BooleanField(verbose_name="User voted this round",default=False)
    asked = models.BooleanField(verbose_name="User asked a question this round",default=False)
    ping = models.BooleanField(verbose_name="Ping me when question is asked",default=True)
    class Meta:
        unique_together = (('d_id','g'))

    def __repr__(self):
        return f"ID:{self.d_id}, gld: {self.g_id}"

    def __str__(self):
        return self.__repr__()

class Question(models.Model):
    u = models.ForeignKey(DBUser,verbose_name="User that asked the question.",on_delete=models.SET_NULL,null=True)

    time = models.DateTimeField(verbose_name="Time of question",default=timezone.now)
    question = models.CharField(max_length=2000,verbose_name="Question to be asked")
    asked = models.BooleanField(verbose_name="If a question was already asked",default=False)

    up_next = models.BooleanField(verbose_name="Mark question as up next for questioning",default=False)
    currently_asked = models.BooleanField(verbose_name="Question that is curently asked", default=False)
    asked_time = models.DateTimeField(verbose_name="Time of question asked",default=None,null=True)

    vote_count = models.IntegerField(verbose_name="Vote count for question",default=0)

    msg_nr = models.IntegerField(verbose_name="Running number of message",null=True,default=None)
    show_count = models.IntegerField(verbose_name="Total number of shows for question",default=0)

    message_id = models.IntegerField(verbose_name="Message id of question",null=True,default=None)

    def __repr__(self):
        return f"Time:{self.time.strftime('%Y-%m-%d %H:%M')}, q: {self.question}"

    def __str__(self):
        return self.__repr__()

class Answer(models.Model):
    time = models.DateTimeField(verbose_name="Time of question", default=timezone.now)
    u = models.ForeignKey(DBUser,verbose_name="User that gave the answer",on_delete=models.CASCADE)
    question = models.ForeignKey(Question,verbose_name="To which question the answer was given.",on_delete=models.CASCADE)
    answer = models.CharField(max_length=2000,verbose_name="Answer that was given")

    vote_count = models.IntegerField(verbose_name="Number of upvotes.", default=0)
    message_id = models.IntegerField(verbose_name="ID of message according to discord.")

    place = models.IntegerField(verbose_name="Place of answer",default=None,null=True)

class Error(models.Model):
    g = models.ForeignKey(DBGuild,on_delete=models.CASCADE,verbose_name="Guild where error happened")
    cmd_string = models.CharField(max_length=512,verbose_name="Command string that was executed")
    error_type = models.CharField(max_length=64,verbose_name="Error type")
    error = models.CharField(max_length=1024,verbose_name="Error string")
    time_stamp =  models.DateTimeField(verbose_name="Time of error.",default=timezone.now)
    traceback = models.CharField(verbose_name="Traceback of error",default=None,null=True,max_length=5000)

    def __repr__(self):
        return f"{self.error} on {self.g.name}"

    def __str__(self):
        return self.__repr__()

class UserIgnore(models.Model):
    user_id = models.IntegerField(verbose_name="User id that should be ignored in messages")